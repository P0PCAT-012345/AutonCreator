
#include <iostream>
#include "vector2.h"

vec2 midpoint = vec2(0, 0);
double theta = 0;
double length = 15;

double t = 0;


transformvec2 differential_kinematics(double Vl, double Vr, double dt){
  
  double x = midpoint.x;
  double y = midpoint.y;

  double R = Vr - Vl == 0 ? INFINITY : (Vl + Vr)/(2*(Vr - Vl));
  

  double w = (Vr - Vl)/length;
  

  vec2 ICC = vec2(x - R*sin(theta), y + R*cos(theta));
  matrix3b3 a = matrix3b3(cos(w*dt), -sin(w*dt), 0, 
                          sin(w*dt), cos(w*dt), 0,
                          0, 0, 1);
  
  transformvec2 b = transformvec2(x - ICC.x, y - ICC.y, theta);
  transformvec2 c = transformvec2(ICC.x, ICC.y, w*dt);

  return a*b + c;
}