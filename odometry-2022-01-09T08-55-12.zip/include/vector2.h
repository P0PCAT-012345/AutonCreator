#include "math.h"

struct vec2 {
   double x, y;

    vec2(double x, double y);

   struct vec2& operator+=(const vec2& rhs) { x += rhs.x; y += rhs.y; return *this; }
   struct vec2& operator-=(const vec2& rhs) { x -= rhs.x; y -= rhs.y; return *this; }
   struct vec2& operator*=(const float& rhs) { x *= rhs; y *= rhs; return *this; }
   struct vec2& operator/=(const float& rhs) { x /= rhs; y /= rhs; return *this; }
   struct vec2& operator*=(const double& rhs) { x *= rhs; y *= rhs; return *this; }
   struct vec2& operator/=(const double& rhs) { x /= rhs; y /= rhs; return *this; }
   struct vec2& operator*=(const int& rhs) { x *= rhs; y *= rhs; return *this; }
   struct vec2& operator/=(const int& rhs) { x /= rhs; y /= rhs; return *this; }
};

vec2 operator+(vec2 lhs, const vec2& rhs) { return lhs += rhs; }
vec2 operator-(vec2 lhs, const vec2& rhs) { return lhs -= rhs; }
vec2 operator*(vec2 lhs, const float& k) { return lhs *= k; }
vec2 operator/(vec2 lhs, const float& k) { return lhs /= k; }
vec2 operator*(const float& k, vec2 rhs) { return rhs *= k; }
vec2 operator/(const float& k, vec2 rhs) { return rhs /= k; }
vec2 operator*(vec2 lhs, const double& k) { return lhs *= k; }
vec2 operator/(vec2 lhs, const double& k) { return lhs /= k; }
vec2 operator*(const double& k, vec2 rhs) { return rhs *= k; }
vec2 operator/(const double& k, vec2 rhs) { return rhs /= k; }
vec2 operator*(vec2 lhs, const int& k) { return lhs *= k; }
vec2 operator/(vec2 lhs, const int& k) { return lhs /= k; }
vec2 operator*(const int& k, vec2 rhs) { return rhs *= k; }
vec2 operator/(const int& k, vec2 rhs) { return rhs /= k; }





struct matrix3b3 {
   double a, b, c;
   double d, e, f;
   double g, h, i;
  
   matrix3b3(double a, double b, double c,
            double d, double e, double f,
            double g, double h, double i);

};

struct transformvec2 {
   double x, y, a;
   
   transformvec2(double x, double y, double a);

   struct transformvec2& operator*=(const matrix3b3& rhs) { x = rhs.a*x + rhs.b*y + rhs.c*a; 
                                                            y = rhs.d*x + rhs.e*y + rhs.f*a; 
                                                            a = rhs.g*x + rhs.h*y + rhs.i*a; return *this; }
   struct transformvec2& operator+=(const transformvec2& rhs) { x += rhs.x; y += rhs.y; a += rhs.a; return *this; }
   struct transformvec2& operator-=(const transformvec2& rhs) { x -= rhs.x; y -= rhs.y; a -= rhs.a; return *this; }

};

transformvec2 operator+(const transformvec2& lhs, transformvec2 rhs) { return rhs += lhs; }
transformvec2 operator-(const transformvec2& lhs, transformvec2 rhs) { return rhs -= lhs; }
transformvec2 operator*(transformvec2 lhs, const matrix3b3& rhs) { return lhs *= rhs; }
transformvec2 operator*(const matrix3b3& lhs, transformvec2 rhs) { return rhs *= lhs; }


float slope_of(vec2 from, vec2 to){
  return from.x - to.x == 0 ? (from.x > to.x ? 270 : 90) : 180/M_PI * (acos((to.y - from.y)/(to.y - from.y)));
}

float distance_to(vec2 from, vec2 to){
  return sqrt(pow(from.x - to.x, 2) + pow(from.y - to.y, 2));
}