/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\kneep                                            */
/*    Created:      Sat Jan 08 2022                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// clamp                motor         1               
// DigitalOutA          digital_out   A               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"
#include <algorithm>
#include <vector>
using namespace std;
using namespace vex;

#include "position-tracking.h"

class wheel{
  public:
    motor m;
    double wheel_diameter;
    double wheel_ratio;
    
    wheel(motor m, double wheel_diameter, double wheel_ratio);
};

class Chasis{
  public:
    vector <wheel> r;
    vector <wheel> l;
    transformvec2 pose = transformvec2(0, 0, 0);
    void set_dimension(vec2 d){
      length = d.x;
    }
    void add_rm(wheel m){
      r.push_back(m);
    }
    void add_lm(wheel m){
      l.push_back(m);
    }
    void odometryTracking(double dt){
      double Ar = 0;
      for(wheel m : r){
        motor mot = m.m;
        Ar += mot.velocity(velocityUnits::rpm) * m.wheel_ratio * m.wheel_diameter * M_PI;
      }
      Ar /= r.size();

      double Al = 0;
      for(wheel m : l){
        motor mot = m.m;
        Al += mot.velocity(velocityUnits::rpm) * m.wheel_ratio * m.wheel_diameter * M_PI;
      }
      Al /= r.size();

      pose = differential_kinematics(Al, Ar, dt);
    }


};

Chasis chasisInit(){
  Chasis c;
  c.set_dimension(vec2(15, 20));
  c.add_lm(wheel(l1, 12, 1));
  c.add_lm(wheel(l2, 12, 1));
  c.add_lm(wheel(l3, 12, 1));
  c.add_lm(wheel(r1, 12, 1));
  c.add_lm(wheel(r2, 12, 1));
  c.add_lm(wheel(r3, 12, 1));

  return c;
}

Chasis c = chasisInit();

bool rotateTo(float theta, float power = 20){
  vector <bool> finished;
  for(wheel m : c.r){
    motor mot = m.m;
    finished.push_back(mot.spinFor(length*(theta/360)/(m.wheel_diameter*m.wheel_ratio), rotationUnits::rev, power, velocityUnits::pct, false));
  }     
  for(wheel m : c.l){
    motor mot = m.m;
    finished.push_back(mot.spinFor(length*(theta/360)/(m.wheel_diameter*m.wheel_ratio), rotationUnits::rev, -power, velocityUnits::pct, false));
  }
  while(true){  
    if (std::all_of(std::begin(finished), std::end(finished), [](bool i){ return i;})) {
        return true;
    }
  }
}

bool driveFor(float mag, float power){
  vector <bool> finished;
  for(wheel m : c.r){
    motor mot = m.m;
    finished.push_back(mot.spinFor(mag/(m.wheel_diameter*m.wheel_ratio*M_PI), rotationUnits::rev, power, velocityUnits::pct, false));
  }
  for(wheel m : c.l){
    motor mot = m.m;
    finished.push_back(mot.spinFor(mag/(m.wheel_diameter*m.wheel_ratio*M_PI), rotationUnits::rev, power, velocityUnits::pct, false));
  }
  while(true){  
    if (std::all_of(std::begin(finished), std::end(finished), [](bool i){ return i;})) {
        return true;
    }
  }
}

bool moveTo(vec2 to, float speed, bool backdrive = false){
  float a = c.pose.a - slope_of(vec2(c.pose.x, c.pose.y), to);
  float dist = distance_to(vec2(c.pose.x, c.pose.y), to);
  if (backdrive){
    a += 360;
    dist *= -1;
  }
  while (abs(a) >= 180){
    a += a > 0 ? -360 : 360;
  }
  if(rotateTo(a)){
    return driveFor(dist, backdrive ? -speed : speed);
  }
  return false;
}
void setDefault(vec2 pos, float angle){
  c.pose.x = pos.x;
  c.pose.y = pos.y;
  c.pose.a = angle;

}


bool motor1(double power, double rotation, bool wait = false){
  return clamp.spinFor(power > 0 ? rotation : -rotation, rotationUnits::rev, power, velocityUnits::pct, wait);
}
bool pneu(bool toggle, bool wait = false){
  if (toggle){
    backclamp.open();
  }
  else{
    backclamp.close();
  }
  task::sleep(wait ? 0 : 500);
  return true;
}


void actionInit(){
setDefault( vec2(1, 9), 360 );
moveTo( vec2(81, 42), 100 );
pneu(True);
moveTo( vec2(17, 23), 20, true );
moveTo( vec2(17, 41), 5, true );
motor1(127, 4, true);
moveTo( vec2(17, 41), 30);
rotateTo(270); 
moveTo( vec2(16, 82), 118 );
moveTo( vec2(16, 97), 5 );


}



int main() {
  vexcodeInit();
  timer timer1;
  timer1.clear();
  double t = timer1.systemHighResolution();
  

  while (true){
    double dt = t - timer1.systemHighResolution();
    t = timer1.systemHighResolution();
    c.odometryTracking(dt);

    actionInit();

  }
}
